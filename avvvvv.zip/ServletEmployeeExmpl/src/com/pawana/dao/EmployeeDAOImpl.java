package com.pawana.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pawana.bean.EmployeeBean;
import com.pawana.dbconnection.SingletonDB;

public class EmployeeDAOImpl implements EmployeeDAO{

	@Override
	public void insertrecord(EmployeeBean emp1) throws SQLException, ClassNotFoundException {
		
		System.out.println("Dao layerf");
		// TODO Auto-generated method stub
		String query="insert into employee1 values(?,?,?,?)";
		Connection con=SingletonDB.getConnection();
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1,emp1.getName());
		ps.setString(2,emp1.getId());
		ps.setString(3,emp1.getAddress());
		ps.setString(4,emp1.getSalary());
		int result=ps.executeUpdate();
		System.out.println("inside dao");
		if(result!=0)
		{
			System.out.println("employee record inserted successfully");

		}
		else
		{
			System.out.println("employee record not inserted successfully");

		}


	}

	@Override
	public void updaterecord() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleterecord() {
		// TODO Auto-generated method stub
		
	}

}
