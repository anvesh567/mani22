package com.pawana.dao;

import java.sql.SQLException;

import com.pawana.bean.EmployeeBean;

public interface EmployeeDAO {
   public void insertrecord(EmployeeBean emp1) throws SQLException, ClassNotFoundException;
   public void updaterecord();
   public void deleterecord();
   
}
