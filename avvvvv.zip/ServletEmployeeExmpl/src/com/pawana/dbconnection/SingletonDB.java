package com.pawana.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SingletonDB {
	private SingletonDB()
	{
		
	}
	
	
	//System.err.println("-----DBConnectionInfo----");
	
	
	private static SingletonDB dbconnectionInfo;
	public static Connection connection;
	private static ResourceBundle bundle;
	private final static String baseName = "com.pawana.nls.employee";
    
	public static SingletonDB getInstance()
	{
		if(dbconnectionInfo==null)
		{
			System.err.println("-----DBConnectionInfo----");
			dbconnectionInfo=new SingletonDB();

		}
		return dbconnectionInfo;
	}
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		if(connection==null)
		{
			System.err.println("-----connection----");
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(getBundle().getString("db.mysql.url"), getBundle().getString("db.mysql.username"),
					getBundle().getString("db.mysql.pwd"));

		}
		return connection;
	}
	public static ResourceBundle getBundle()
	{
		if(bundle==null)
		{
			  bundle =  ResourceBundle.getBundle(baseName);

		}
		return bundle;
	}


}
