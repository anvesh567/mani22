package com.pawana.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pawana.bean.EmployeeBean;
import com.pawana.dao.EmployeeDAO;
import com.pawana.dao.EmployeeDAOImpl;

public class ServletInsertRecord extends HttpServlet {
	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
	{
		response.setContentType("text/html");
		try
		{
			PrintWriter pw=response.getWriter();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" in servlet");
		String name=request.getParameter(" name");
		String id=request.getParameter("id");
		String address=request.getParameter("address");
        String salary=request.getParameter("salary");
        EmployeeBean emp=new EmployeeBean();
        emp.setName(name);
        emp.setId(id);
        emp.setAddress(address);
        emp.setSalary(salary);
        EmployeeDAOImpl empl=new EmployeeDAOImpl();
        
        
        try {
        	System.out.println("hiiii");
				empl.insertrecord(emp);
				System.out.println("inside method");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			// TODO Auto-generated catch block

		}

		
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	{
		
		doGet(request, response);
	}

	
}
